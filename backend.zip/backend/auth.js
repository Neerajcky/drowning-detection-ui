const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pool = require("./config");
const router = express.Router();

// Admin Registration (For Testing)
router.post("/register", async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const newAdmin = await pool.query(
      "INSERT INTO admin (username, password) VALUES ($1, $2) RETURNING *",
      [username, hashedPassword]
    );
    res.status(201).json({ message: "Admin Registered", admin: newAdmin.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin Login
router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  try {
    const admin = await pool.query("SELECT * FROM admin WHERE username = $1", [username]);
    if (admin.rows.length === 0) return res.status(401).json({ message: "Invalid credentials" });

    const validPassword = await bcrypt.compare(password, admin.rows[0].password);
    if (!validPassword) return res.status(401).json({ message: "Invalid credentials" });

    const token = jwt.sign({ id: admin.rows[0].id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.json({ message: "Login successful", token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
