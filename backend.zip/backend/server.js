const express = require("express");
const dotenv = require("dotenv");
const pool = require("./config"); // Your database connection
const routes = require("./routes");

dotenv.config();
const app = express();

app.use(express.json()); // Middleware to parse JSON requests

// Default route to check if the server is running
app.get("/", (req, res) => {
  res.send("Welcome to the Drowning Detection API");
});

app.use("/", routes); // Attach your existing routes

const PORT = process.env.PORT || 6000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
