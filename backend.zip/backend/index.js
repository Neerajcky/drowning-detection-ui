const cors = require("cors");

app.use(cors({
  origin: "http://localhost:5173", // Allow frontend to access backend
  credentials: true,
}));
