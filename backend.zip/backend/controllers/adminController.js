const Admin = require("./models/Admin");

// Add new admin
const addAdmin = async (req, res) => {
    try {
        const { name, phone } = req.body;
        const newAdmin = await Admin.create({ name, phone });
        res.status(201).json({ message: "Admin added successfully", admin: newAdmin });
    } catch (error) {
        res.status(500).json({ message: "Error adding admin", error });
    }
};

// Get all admins
const getAdmins = async (req, res) => {
    try {
        const admins = await Admin.findAll();
        res.status(200).json(admins);
    } catch (error) {
        res.status(500).json({ message: "Error fetching admins", error });
    }
};

// Delete admin by ID
const deleteAdmin = async (req, res) => {
    try {
        const { id } = req.params;
        await Admin.destroy({ where: { id } });
        res.status(200).json({ message: "Admin deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error deleting admin", error });
    }
};

module.exports = { addAdmin, getAdmins, deleteAdmin };
