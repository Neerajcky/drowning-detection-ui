const express = require("express");
const jwt = require("jsonwebtoken");
const pool = require("./config");
const router = express.Router();

const verifyToken = (req, res, next) => {
    const token = req.headers["authorization"];
    
    if (!token) {
      console.log("🔴 No token received");
      return res.status(403).json({ message: "Access denied" });
    }
  
    // Extract token from "Bearer <token>"
    const actualToken = token.split(" ")[1];
    console.log("🟢 Received Token:", actualToken);
  
    jwt.verify(actualToken, process.env.JWT_SECRET, (err, decoded) => {
      if (err) {
        console.log("🔴 JWT Verification Error:", err.message);
        return res.status(401).json({ message: "Invalid token" });
      }
  
      console.log("✅ Decoded Token:", decoded);
      req.adminId = decoded.id;
      next();
    });
  };
  

// 🟢 Add Admin
router.post("/admin", async (req, res) => {
  const { name, phone } = req.body;
  try {
    await pool.query("INSERT INTO admin (name, phone) VALUES ($1, $2)", [name, phone]);
    res.status(201).json({ message: "Admin added" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟢 Get All Admins
router.get("/admin", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM admin");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟢 Delete Admin
router.delete("/admin/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM admin WHERE id = $1", [id]);
    res.status(200).json({ message: "Admin removed" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟢 Add Supervisor
router.post("/supervisors", verifyToken, async (req, res) => {
  const { name, phone } = req.body;
  try {
    await pool.query("INSERT INTO supervisors (name, phone) VALUES ($1, $2)", [name, phone]);
    res.status(201).json({ message: "Supervisor added" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟢 Add Lifeguard
router.post("/lifeguards", verifyToken, async (req, res) => {
  const { name, phone } = req.body;
  try {
    await pool.query("INSERT INTO lifeguards (name, phone) VALUES ($1, $2)", [name, phone]);
    res.status(201).json({ message: "Lifeguard added" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟢 Fetch Videos
router.get("/videos", verifyToken, async (req, res) => {
  try {
    const videos = await pool.query("SELECT * FROM videos");
    res.json(videos.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟢 Admin Login (Generates JWT Token)
router.post("/login", async (req, res) => {
    const { username, password } = req.body;
  
    // Dummy admin credentials (Replace this with database validation)
    const ADMIN_USERNAME = "admin";
    const ADMIN_PASSWORD = "adminpassword"; // In real cases, use bcrypt for hashing
  
    if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
      return res.status(401).json({ message: "Invalid username or password" });
    }
  
    // Generate JWT Token
    const token = jwt.sign({ id: 1, role: "admin" }, process.env.JWT_SECRET, { expiresIn: "1h" });
  
    res.json({ token });
  });
  

module.exports = router;
